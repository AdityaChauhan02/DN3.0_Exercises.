package algorithms_datastructure;
interface PaymentProcessor {
    void processPayment(String paymentMethod, double amount);
}

class PayPalGateway {
    public void payWithPayPal(String paymentMethod, double amount) {
        System.out.println("Processing payment with PayPal: " + paymentMethod + " - $" + amount);
    }
}

class StripeGateway {
    public void chargeWithStripe(String paymentMethod, double amount) {
        System.out.println("Processing payment with Stripe: " + paymentMethod + " - $" + amount);
    }
}

class BankTransferGateway {
    public void transferWithBank(String paymentMethod, double amount) {
        System.out.println("Processing payment with Bank Transfer: " + paymentMethod + " - $" + amount);
    }
}

class PayPalAdapter implements PaymentProcessor {
    private PayPalGateway payPalGateway;

    public PayPalAdapter(PayPalGateway payPalGateway) {
        this.payPalGateway = payPalGateway;
    }

    public void processPayment(String paymentMethod, double amount) {
        payPalGateway.payWithPayPal(paymentMethod, amount);
    }
}

class StripeAdapter implements PaymentProcessor {
    private StripeGateway stripeGateway;

    public StripeAdapter(StripeGateway stripeGateway) {
        this.stripeGateway = stripeGateway;
    }

    public void processPayment(String paymentMethod, double amount) {
        stripeGateway.chargeWithStripe(paymentMethod, amount);
    }
}

class BankTransferAdapter implements PaymentProcessor {
    private BankTransferGateway bankTransferGateway;

    public BankTransferAdapter(BankTransferGateway bankTransferGateway) {
        this.bankTransferGateway = bankTransferGateway;
    }

    public void processPayment(String paymentMethod, double amount) {
        bankTransferGateway.transferWithBank(paymentMethod, amount);
    }
}


public class AdapterPattern {
    public static void main(String[] args) {
        
        PayPalGateway payPalGateway = new PayPalGateway();
        PayPalAdapter payPalAdapter = new PayPalAdapter(payPalGateway);

        StripeGateway stripeGateway = new StripeGateway();
        StripeAdapter stripeAdapter = new StripeAdapter(stripeGateway);

        BankTransferGateway bankTransferGateway = new BankTransferGateway();
        BankTransferAdapter bankTransferAdapter = new BankTransferAdapter(bankTransferGateway);

       
        System.out.println("Processing payment with PayPal:");
        payPalAdapter.processPayment("Credit Card", 100.0);

        System.out.println("Processing payment with Stripe:");
        stripeAdapter.processPayment("Debit Card", 50.0);

        System.out.println("Processing payment with Bank Transfer:");
        bankTransferAdapter.processPayment("Bank Account", 200.0);
    }
}
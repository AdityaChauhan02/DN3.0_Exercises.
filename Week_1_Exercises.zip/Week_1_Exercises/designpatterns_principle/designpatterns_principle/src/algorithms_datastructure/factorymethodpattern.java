package algorithms_datastructure;

import java.util.HashMap;
import java.util.Map;

public class factorymethodpattern {

    public static void main(String[] args) {
        DocumentFactory factory = new DocumentFactory();

        Document wordDocument = factory.createDocument("Word");
        System.out.println("Created Word document: " + wordDocument.getClass().getSimpleName());

        Document pdfDocument = factory.createDocument("PDF");
        System.out.println("Created PDF document: " + pdfDocument.getClass().getSimpleName());

        Document excelDocument = factory.createDocument("Excel");
        System.out.println("Created Excel document: " + excelDocument.getClass().getSimpleName());
    }
}

interface Document {
    void open();
    void save();
}

class WordDocument implements Document {
    @Override
    public void open() {
        System.out.println("Opening Word document.");
    }

    @Override
    public void save() {
        System.out.println("Saving Word document.");
    }
}

class PdfDocument implements Document {
    @Override
    public void open() {
        System.out.println("Opening PDF document.");
    }

    @Override
    public void save() {
        System.out.println("Saving PDF document.");
    }
}

class ExcelDocument implements Document {
    @Override
    public void open() {
        System.out.println("Opening Excel document.");
    }

    @Override
    public void save() {
        System.out.println("Saving Excel document.");
    }
}

interface DocumentFactoryInterface {
    Document create();
}

class WordDocumentFactory implements DocumentFactoryInterface {
    @Override
    public Document create() {
        return new WordDocument();
    }
}

class PdfDocumentFactory implements DocumentFactoryInterface {
    @Override
    public Document create() {
        return new PdfDocument();
    }
}

class ExcelDocumentFactory implements DocumentFactoryInterface {
    @Override
    public Document create() {
        return new ExcelDocument();
    }
}

class DocumentFactory {
    private Map<String, DocumentFactoryInterface> factoryMap = new HashMap<>();

    public DocumentFactory() {
        factoryMap.put("Word", new WordDocumentFactory());
        factoryMap.put("PDF", new PdfDocumentFactory());
        factoryMap.put("Excel", new ExcelDocumentFactory());
    }

    public Document createDocument(String documentType) {
        DocumentFactoryInterface concreteFactory = factoryMap.get(documentType);
        if (concreteFactory!= null) {
            return concreteFactory.create();
        } else {
            System.out.println("Unsupported document type: " + documentType);
            return null;
        }
    }
}
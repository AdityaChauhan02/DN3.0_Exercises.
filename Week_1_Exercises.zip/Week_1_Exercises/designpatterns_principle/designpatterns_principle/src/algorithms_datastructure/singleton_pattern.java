package algorithms_datastructure;

public class singleton_pattern {
	    private static volatile singleton_pattern instance;
	    private singleton_pattern() {}
	    public static singleton_pattern getInstance() {
	        if (instance == null) {
	            synchronized (singleton_pattern.class) {
	                if (instance == null) {
	                    instance = new singleton_pattern();
	                }
	            }
	        }
	        return instance;
	    }
	    public void log(String message) {
	        System.out.println("Logging: " + message);
	    }

	    public static void main(String[] args) {
	    	singleton_pattern logger1 = singleton_pattern.getInstance();
	    	singleton_pattern logger2 = singleton_pattern.getInstance();
	        System.out.println("Is logger1 the same as logger2? " + (logger1 == logger2));
	        logger1.log("Hello, World!");
	        logger2.log("This is another log message.");
	    }
	}
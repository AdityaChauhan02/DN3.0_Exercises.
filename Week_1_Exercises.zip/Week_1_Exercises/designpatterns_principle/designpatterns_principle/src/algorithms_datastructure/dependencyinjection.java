package algorithms_datastructure;
interface CustomerRepository {
    Customer findCustomerById(int id);
}


class CustomerRepositoryImpl implements CustomerRepository {
    @Override
    public Customer findCustomerById(int id) {
       
        Customer customer = new Customer(id, "Aditya Tathaghat Chauhan", "adityachauhan@example.com");
        return customer;
    }
}

class CustomerService {
    private CustomerRepository customerRepository;

    public CustomerService(CustomerRepository customerRepository) {
        this.customerRepository = customerRepository;
    }

    public Customer findCustomer(int id) {
        return customerRepository.findCustomerById(id);
    }
}

class Customer {
    private int id;
    private String name;
    private String email;

    public Customer(int id, String name, String email) {
        this.id = id;
        this.name = name;
        this.email = email;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }
}


public class dependencyinjection {
    public static void main(String[] args) {
        
        CustomerRepository customerRepository = new CustomerRepositoryImpl();

       
        CustomerService customerService = new CustomerService(customerRepository);

        
        int customerId = 1;
        Customer customer = customerService.findCustomer(customerId);

        
        System.out.println("Customer found: " + customer.getName() + " (" + customer.getEmail() + ")");
    }
}
public class TaskManagement {

    static class Task {
        int taskId;
        String taskName;
        String status;
        Task next;

        public Task(int taskId, String taskName, String status) {
            this.taskId = taskId;
            this.taskName = taskName;
            this.status = status;
            this.next = null;
        }
    }

    static class TaskList {
        Task head;

        public void addTask(Task task) {
            if (head == null) {
                head = task;
            } else {
                Task current = head;
                while (current.next != null) {
                    current = current.next;
                }
                current.next = task;
            }
        }

        public void searchTask(int taskId) {
            Task current = head;
            while (current != null) {
                if (current.taskId == taskId) {
                    System.out.println("Task found: " + current.taskName + " with status " + current.status);
                    return;
                }
                current = current.next;
            }
            System.out.println("Task not found");
        }

        public void traverseTasks() {
            Task current = head;
            while (current != null) {
                System.out.println("Task " + current.taskId + ": " + current.taskName + " with status " + current.status);
                current = current.next;
            }
        }

        public void deleteTask(int taskId) {
            if (head == null) return;

            if (head.taskId == taskId) {
                head = head.next;
                return;
            }

            Task current = head;
            while (current.next != null) {
                if (current.next.taskId == taskId) {
                    current.next = current.next.next;
                    return;
                }
                current = current.next;
            }
        }
    }

    public static void main(String[] args) {
        TaskList taskList = new TaskList();

        taskList.addTask(new Task(1, "Task 1", "In Progress"));
        taskList.addTask(new Task(2, "Task 2", "Completed"));
        taskList.addTask(new Task(3, "Task 3", "Pending"));

        taskList.traverseTasks();

        taskList.searchTask(2);

        taskList.deleteTask(2);

        taskList.traverseTasks();
    }
}
import java.util.Arrays;

public class LibraryManagementSystem {
    private Book[] books;

    public LibraryManagementSystem(Book[] books) {
        this.books = books;
    }
    public static class Book {
        private int bookId;
        private String title;
        private String author;

        public Book(int bookId, String title, String author) {
            this.bookId = bookId;
            this.title = title;
            this.author = author;
        }
        public int getBookId() {
            return bookId;
        }

        public void setBookId(int bookId) {
            this.bookId = bookId;
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public String getAuthor() {
            return author;
        }

        public void setAuthor(String author) {
            this.author = author;
        }
    }
    public Book linearSearchByTitle(String title) {
        for (Book book : books) {
            if (book.getTitle().equals(title)) {
                return book;
            }
        }
        return null;
    }
    public Book binarySearchByTitle(String title) {
        Arrays.sort(books, (b1, b2) -> b1.getTitle().compareTo(b2.getTitle()));
        int low = 0;
        int high = books.length - 1;

        while (low <= high) {
            int mid = (low + high) / 2;
            if (books[mid].getTitle().equals(title)) {
                return books[mid];
            } else if (books[mid].getTitle().compareTo(title) < 0) {
                low = mid + 1;
            } else {
                high = mid - 1;
            }
        }
        return null;
    }

    public static void main(String[] args) {
        Book[] books = new Book[] {
            new Book(1, "Book A1", "Author A"),
            new Book(2, "Book A2", "Author B"),
            new Book(3, "Book A3", "Author C"),
            new Book(4, "Book A4", "Author D"),
            new Book(5, "Book A5", "Author E")
        };

        LibraryManagementSystem library = new LibraryManagementSystem(books);

        Book book = library.linearSearchByTitle("Book A2");
        if (book!= null) {
            System.out.println("Linearsearch found: " + book.getTitle() + " by " + book.getAuthor());
        } else {
            System.out.println("Linearsearch not found");
        }

        book = library.binarySearchByTitle("Book A4");
        if (book!= null) {
            System.out.println("Binarysearch found: " + book.getTitle() + " by " + book.getAuthor());
        } else {
            System.out.println("Binarysearch not found");
        }
    }
}
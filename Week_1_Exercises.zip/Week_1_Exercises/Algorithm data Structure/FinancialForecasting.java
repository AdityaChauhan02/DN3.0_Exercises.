public class FinancialForecasting {

    public static double calculateFutureValue(double initialValue, double[] growthRates, int years) {
        if (years == 0) {
            return initialValue;
        } else {
            return calculateFutureValue(initialValue * (1 + growthRates[years - 1]), growthRates, years - 1);
        }
    }

    
    public static double calculateFutureValueIterative(double initialValue, double[] growthRates, int years) {
        double futureValue = initialValue;
        for (int i = 0; i < years; i++) {
            futureValue *= (1 + growthRates[i]);
        }
        return futureValue;
    }

    public static void main(String[] args) {
       
        double initialValue = 1020.0;
        double[] growthRates = {0.25, 0.05, 0.02, 0.03, 0.07}; 
        int years = growthRates.length; 

        
        double futureValueRecursive = calculateFutureValue(initialValue, growthRates, years);
        System.out.println("Future value after " + years + " years (recursive): " + futureValueRecursive);

        
        double futureValueIterative = calculateFutureValueIterative(initialValue, growthRates, years);
        System.out.println("Future value after " + years + " years (iterative): " + futureValueIterative);
    }
}